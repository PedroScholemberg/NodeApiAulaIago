class Imagem {
    constructor(id, nome, data_criacao, titulo) {
        this.id = id;
        this.nome = nome;
        this.data_criacao = data_criacao;
        this.titulo = titulo;
    }
}

module.exports = Imagem;
